import 'package:flutter/material.dart';

class Ass extends StatelessWidget {
  const Ass({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Text('ass'),
      ),
    );
  }
}
