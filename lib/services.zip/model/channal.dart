class ChannalModel {
  String name;
  int time;
  double value;
  ChannalModel({this.time = 0, this.value = 0, this.name = "ch1"});
}
