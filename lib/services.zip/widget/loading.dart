import 'dart:async';
import 'package:flutter/material.dart';

class RequestLoading extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: CircularProgressIndicator());
  }
}
